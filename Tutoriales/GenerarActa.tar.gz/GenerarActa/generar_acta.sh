#!/bin/bash

# generar_actas.sh
# Autor: Luis Sanjuan
# Fecha: 2014-2015

# Este script produce un fichero pdf a partir de un acta dada
# escrita en formato markdown.
# --- Uso
#       ---------------------------------
#       generar_acta.sh <fichero_acta.md>
#       ---------------------------------
# --- Asunciones 
# * El nombre del fichero del acta incorpora la siguiente información
#   en este formato preciso:
#     Nombre de fichero: aXX_0203141530, donde
#     - 02 es el día 
#     - 03 es el mes
#     - 14 es el año (2014),
#     - 1530 es la hora de comienzo de la sesión (15:30)
#       Estos ultimos cuatro números son opcionales. 
#       Si no se proporcionan se toma el valor de la variable
#       $starting_hour inicializada en la sección 'Constantes'
#       más abajo como hora de inicio de sesión.
# -- Nota:
# Para procesamiento de lotes de actas probar algo como esto:
#      --------------------------------------------------------
#      for acta in $(ls *.md); do ./generar_acta.sh $acta; done
#      --------------------------------------------------------
# TAREAS PENDIENTES:
# * Implementar hora de cierre de sesión. En la versión actual la hora
#   de cierre se computa como una hora más que la de inicio.
# * Implementar la exclusion of profesores ausentes, por ejemplo
#   suministrando una opción --exclude 'NombreProfesor' ...
# ----------------------------------------------------------------------------
# 
# -- Constantes 
starting_hour=2000
file="$1"
pandoc_template="plantilla_acta.latex"
background="background2.pdf"
yamlskel="variables.yaml"
declare -a months
months=('enero' 'febrero' 'marzo' 'abril' 'mayo' 'junio' \
	'julio' 'agosto' 'septiembre' 'octubre' 'noviembre' 'diciembre') 
file_bname="${file%*.*}"
od_file="$file_bname"_od.md

# -- Funciones
# Extrae y almacena información de fecha/hora a partir del nombre de fichero
function get_raw_info () {
  local daytime="${file_bname#*_*}"

  raw_day="${daytime:0:2}"
  raw_month="${daytime:2:2}"
  raw_year="${daytime:4:2}"
  raw_hour="${daytime:6:4}"
}

# Elimina del argumento (2 digitos) los ceros iniciales, si hay alguno
# Ej: 03 -> 3, 12 -> 12
function normalize_bidigit () {
  if [ ${1:0:1} = '0' ]; then
    echo "${1:1:1}"
  else
    echo "$1"
  fi
}

# Normaliza el día 
function normalize_day () {
  day=$(normalize_bidigit $raw_day)
}

# Normaliza el mes 
function normalize_month () {
  normalize_bidigit $raw_month
}

# Produce el nombre del mes de su número. Ej: 3 -> marzo
function month_to_string () {
  month=(${months[$(($1 - 1))]})
}

# Normaliza el año. Ej: 14 -> 2014
function normalize_year () {
  year="20${raw_year}"
}

# Convierte la hora en una cadena convencional Ej 2215 -> 22:15
hour_to_string () {
  echo ${1:0:2}:${1:2:2}
} 

# Establece y normaliza la hora de inicio de sesión 
function normalize_start_hour () {
  if [ -z $raw_hour ]; then
    starth=$(hour_to_string $starting_hour)
  else
    starth=$(hour_to_string $raw_hour)
  fi
}

# Computa, sumando una hora, y normaliza la hora de cierre de sesión
function normalize_end_hour () {
  if [ -z $raw_hour ]; then
    endh=$(hour_to_string $(($starting_hour + 100)))
  else
    endh=$(hour_to_string $(($raw_hour + 100)))
  fi
}

# Normaliza todas las variables que lo requieren
function normalize () {
  get_raw_info
  normalize_day
  month_to_string $(normalize_month)
  normalize_year
  normalize_start_hour
  normalize_end_hour
}

# Produce el orden del día como fichero Markdown 
function generate_od () {
  grep '^[[:digit:]]\. \+[[:alnum:]]' "$file" > "$od_file"
}

# Crea un bloque de metadatos YAML para el acta actual
function fill_yaml () {
  sed "s/day:.*/day: $day/g;\
       s/month:.*/month: $month/g;\
       s/year:.*/year: $year/g;\
       s/od:.*/od: ${file_bname//_/}od/g;\
       s/start:.*/start: $starth/g;\
       s/end:.*/end: $endh/g" $yamlskel > "${file_bname}".yaml 
}

function generate_pdf () {
  # Genera orden del día convertido a LaTeX
  # (Nota: LaTeX no acepta por defecto nombres de ficheros 
  # con guiones para \input)
  generate_od
  pandoc -o ${file_bname//_/}od.tex $od_file

  # Genera el pdf 
  pandoc -s --template "$pandoc_template" -o ${file_bname}_tmp.pdf \
    ${file_bname}.md ${file_bname}.yaml 

  # Inserta el logo como marca de agua 
  pdftk ${file_bname}_tmp.pdf background $background output ${file_bname}.pdf

  # Limpia ficheros temporales e intermedios 
  rm *.tex ${file_bname}_tmp.pdf ${file_bname}_od.md ${file_bname}.yaml
}

# -- Main 
normalize
fill_yaml
generate_pdf

# ---------- END OF CODE -----------------------------------------------------
